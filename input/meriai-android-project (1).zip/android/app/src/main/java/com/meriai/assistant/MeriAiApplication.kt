package com.meriai.assistant

import android.app.Application
import com.meriai.assistant.data.AppDatabase

class MeriAiApplication : Application() {
    val database: AppDatabase by lazy { AppDatabase.getDatabase(this) }

    override fun onCreate() {
        super.onCreate()
    }
}
