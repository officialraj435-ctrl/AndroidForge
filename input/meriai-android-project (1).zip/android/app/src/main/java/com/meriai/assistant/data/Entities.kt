package com.meriai.assistant.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val role: String, // "user" or "assistant"
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val suggestedMemoryKey: String? = null,
    val suggestedMemoryValue: String? = null,
    val suggestedTaskTitle: String? = null
)

@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val key: String,
    val value: String,
    val category: String, // "preference", "personal", "work", "habit"
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val type: String, // "todo", "reminder", "note"
    val priority: String, // "low", "medium", "high"
    val dueTime: String? = null,
    val completed: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
