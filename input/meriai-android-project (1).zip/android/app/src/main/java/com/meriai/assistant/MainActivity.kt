package com.meriai.assistant

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.meriai.assistant.ai.GeminiRepository
import com.meriai.assistant.data.*
import com.meriai.assistant.speech.SpeechManager
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var speechManager: SpeechManager
    private val geminiRepo = GeminiRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        speechManager = SpeechManager(
            context = this,
            onSpeechResult = { text, isFinal -> },
            onSpeechError = { error ->
                Toast.makeText(this, error, Toast.LENGTH_SHORT).show()
            },
            onListeningStateChanged = { isListening -> }
        )

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFF6366F1),
                    secondary = Color(0xFF8B5CF6),
                    background = Color(0xFF0F172A),
                    surface = Color(0xFF1E293B)
                )
            ) {
                MainAppScreen(
                    speechManager = speechManager,
                    geminiRepo = geminiRepo,
                    appDatabase = (application as MeriAiApplication).database
                )
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        speechManager.release()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScreen(
    speechManager: SpeechManager,
    geminiRepo: GeminiRepository,
    appDatabase: AppDatabase
) {
    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf("Chat", "Memory", "Tasks", "Settings")

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("Meri AI", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                        ) {
                            Text(
                                "Hinglish",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                tabs.forEachIndexed { index, title ->
                    val icon = when (index) {
                        0 -> Icons.Default.ChatBubble
                        1 -> Icons.Default.Psychology
                        2 -> Icons.Default.Checklist
                        else -> Icons.Default.Settings
                    }
                    NavigationBarItem(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        icon = { Icon(icon, contentDescription = title) },
                        label = { Text(title) }
                    )
                }
            }
        }
    ) { paddingValues ->
        Box(modifier = Modifier.padding(paddingValues)) {
            when (selectedTab) {
                0 -> NativeChatView(speechManager, geminiRepo, appDatabase)
                1 -> NativeMemoryView(appDatabase)
                2 -> NativeTasksView(appDatabase)
                3 -> NativeSettingsView(appDatabase)
            }
        }
    }
}

@Composable
fun NativeChatView(speechManager: SpeechManager, geminiRepo: GeminiRepository, db: AppDatabase) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var inputText by remember { mutableStateOf("") }
    var isListening by remember { mutableStateOf(false) }
    var isThinking by remember { mutableStateOf(false) }

    val messages by db.chatDao().getAllMessages().collectAsState(initial = emptyList())
    val memories by db.memoryDao().getAllMemories().collectAsState(initial = emptyList())
    val tasks by db.taskDao().getAllTasks().collectAsState(initial = emptyList())

    // Safe Runtime Permission Request for RECORD_AUDIO
    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            isListening = true
            speechManager.startListening("hi-IN")
        } else {
            Toast.makeText(context, "Microphone permission zaruri hai voice chat ke liye", Toast.LENGTH_SHORT).show()
        }
    }

    Column(modifier = Modifier.fillMaxSize().background(Color(0xFF0B0F19))) {
        LazyColumn(
            modifier = Modifier.weight(1f).padding(horizontal = 12.dp),
            reverseLayout = false
        ) {
            items(messages) { message ->
                val isUser = message.role == "user"
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                ) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = if (isUser) MaterialTheme.colorScheme.primary else Color(0xFF1E293B),
                        modifier = Modifier.widthIn(max = 280.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(message.content, color = Color.White, fontSize = 14.sp)
                            if (!isUser) {
                                IconButton(
                                    onClick = { speechManager.speak(message.content) },
                                    modifier = Modifier.size(24.dp).align(Alignment.End)
                                ) {
                                    Icon(Icons.Default.VolumeUp, contentDescription = "Play voice", tint = Color.LightGray)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Bottom Input Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF1E293B))
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = {
                val hasPermission = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.RECORD_AUDIO
                ) == PackageManager.PERMISSION_GRANTED

                if (hasPermission) {
                    if (isListening) {
                        speechManager.stopListening()
                        isListening = false
                    } else {
                        speechManager.startListening("hi-IN")
                        isListening = true
                    }
                } else {
                    micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }
            }) {
                Icon(
                    if (isListening) Icons.Default.MicOff else Icons.Default.Mic,
                    contentDescription = "Mic",
                    tint = if (isListening) Color.Red else MaterialTheme.colorScheme.primary
                )
            }

            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Hinglish mein puchein...", fontSize = 14.sp) },
                maxLines = 3
            )

            IconButton(
                onClick = {
                    if (inputText.isNotBlank()) {
                        val userText = inputText
                        inputText = ""
                        coroutineScope.launch {
                            db.chatDao().insertMessage(ChatMessageEntity(role = "user", content = userText))
                            isThinking = true
                            val result = geminiRepo.generateHinglishResponse(
                                prompt = userText,
                                assistantName = "Meri AI",
                                personality = "Friendly Dost",
                                memories = memories,
                                tasks = tasks
                            )
                            isThinking = false
                            val reply = result.getOrElse { it.message ?: "Network error" }
                            db.chatDao().insertMessage(ChatMessageEntity(role = "assistant", content = reply))
                            speechManager.speak(reply)
                        }
                    }
                }
            ) {
                Icon(Icons.Default.Send, contentDescription = "Send", tint = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@Composable
fun NativeMemoryView(db: AppDatabase) {
    val memories by db.memoryDao().getAllMemories().collectAsState(initial = emptyList())
    var showConfirmDeleteAll by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Memory Bank", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Color.White)
            TextButton(onClick = { showConfirmDeleteAll = true }) {
                Text("Clear All", color = Color.Red)
            }
        }
        Text("Saved 100% locally on your phone", fontSize = 12.sp, color = Color.Gray)
        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn {
            items(memories) { mem ->
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(mem.key, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                            Text(mem.value, color = Color.White, fontSize = 14.sp)
                        }
                        IconButton(onClick = {
                            coroutineScope.launch { db.memoryDao().deleteMemory(mem) }
                        }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Gray)
                        }
                    }
                }
            }
        }

        // Sensitive Action Confirmation Dialog
        if (showConfirmDeleteAll) {
            AlertDialog(
                onDismissRequest = { showConfirmDeleteAll = false },
                title = { Text("Clear All Memories?") },
                text = { Text("Yeh action aapki saari saved memories delete kar dega. Kya aap sure hain?") },
                confirmButton = {
                    Button(
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                        onClick = {
                            coroutineScope.launch { db.memoryDao().clearAllMemories() }
                            showConfirmDeleteAll = false
                        }
                    ) { Text("Delete Everything") }
                },
                dismissButton = {
                    TextButton(onClick = { showConfirmDeleteAll = false }) { Text("Cancel") }
                }
            )
        }
    }
}

@Composable
fun NativeTasksView(db: AppDatabase) {
    val tasks by db.taskDao().getAllTasks().collectAsState(initial = emptyList())
    val coroutineScope = rememberCoroutineScope()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Tasks & Reminders", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Color.White)
        Spacer(modifier = Modifier.height(12.dp))
        LazyColumn {
            items(tasks) { task ->
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = task.completed,
                            onCheckedChange = { checked ->
                                coroutineScope.launch { db.taskDao().updateTask(task.copy(completed = checked)) }
                            }
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(task.title, fontWeight = FontWeight.Medium, color = Color.White)
                            task.dueTime?.let { Text(it, fontSize = 12.sp, color = Color.Gray) }
                        }
                        IconButton(onClick = {
                            coroutineScope.launch { db.taskDao().deleteTask(task) }
                        }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Gray)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun NativeSettingsView(db: AppDatabase) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Assistant Settings", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Color.White)
        Spacer(modifier = Modifier.height(16.dp))
        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Assistant Name", color = Color.Gray, fontSize = 12.sp)
                Text("Meri AI", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 16.sp)
                Spacer(modifier = Modifier.height(12.dp))
                Text("Personality", color = Color.Gray, fontSize = 12.sp)
                Text("Friendly Dost (Hinglish)", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 16.sp)
            }
        }
    }
}
