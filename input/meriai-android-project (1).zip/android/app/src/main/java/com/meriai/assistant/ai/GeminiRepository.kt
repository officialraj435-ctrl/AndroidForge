package com.meriai.assistant.ai

import com.meriai.assistant.BuildConfig
import com.meriai.assistant.data.MemoryEntity
import com.meriai.assistant.data.TaskEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiRepository {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    // Key is securely fetched from BuildConfig (which reads local.properties at build time)
    // NEVER commit hardcoded API keys to Version Control.
    private val apiKey: String = BuildConfig.GEMINI_API_KEY

    suspend fun generateHinglishResponse(
        prompt: String,
        assistantName: String,
        personality: String,
        memories: List<MemoryEntity>,
        tasks: List<TaskEntity>
    ): Result<String> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank() || apiKey == "YOUR_API_KEY_HERE") {
            return@withContext Result.failure(
                Exception("API Key missing! Add GEMINI_API_KEY=your_key in local.properties.")
            )
        }

        try {
            val memoryContext = if (memories.isNotEmpty()) {
                memories.joinToString("\n") { "- ${it.key}: ${it.value}" }
            } else {
                "No saved user memories yet."
            }

            val taskContext = if (tasks.isNotEmpty()) {
                tasks.filter { !it.completed }.joinToString("\n") { "- [${it.type}] ${it.title} (${it.priority})" }
            } else {
                "No pending tasks."
            }

            val systemInstruction = """
                You are "$assistantName", a warm, intelligent personal AI assistant for Android.
                Personality: $personality.
                Language: Speak naturally in friendly Hinglish (Hindi written using English/Latin alphabet), just like young Indians and WhatsApp chat.
                Examples: "Haan bilkul!", "Kya haal chaal?", "Fikr mat karo, main sambhal loongi!", "Aapka reminder note kar liya hai."
                
                Memory Bank (User Facts):
                $memoryContext
                
                Active Tasks:
                $taskContext
                
                If the user mentions a personal fact, suggest saving it at the end with [MEMORY_SUGGESTION: key | value].
                If the user asks for a reminder/todo, add [TASK_SUGGESTION: title | type | priority].
            """.trimIndent()

            val requestBodyJson = JSONObject().apply {
                val contentsArray = JSONArray().apply {
                    put(JSONObject().apply {
                        put("role", "user")
                        put("parts", JSONArray().apply {
                            put(JSONObject().put("text", prompt))
                        })
                    })
                }
                put("contents", contentsArray)

                val systemInstructionObj = JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().put("text", systemInstruction))
                    })
                }
                put("systemInstruction", systemInstructionObj)
            }

            val mediaType = "application/json; charset=utf-8".toMediaType()
            val body = requestBodyJson.toString().toRequestBody(mediaType)

            // Using the official Gemini model alias for general text
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=$apiKey"

            val request = Request.Builder()
                .url(url)
                .post(body)
                .header("User-Agent", "MeriAI-Android")
                .build()

            val response = client.newCall(request).execute()
            val responseString = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("HTTP ${response.code}: $responseString"))
            }

            val jsonResponse = JSONObject(responseString)
            val candidates = jsonResponse.optJSONArray("candidates")
            if (candidates != null && candidates.length() > 0) {
                val firstCandidate = candidates.getJSONObject(0)
                val content = firstCandidate.optJSONObject("content")
                val parts = content?.optJSONArray("parts")
                if (parts != null && parts.length() > 0) {
                    val text = parts.getJSONObject(0).optString("text", "")
                    return@withContext Result.success(text)
                }
            }

            Result.failure(Exception("Invalid response format from Gemini API"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
