# Add project specific ProGuard rules here.
# Keep Room database schemas and entities
-keep class androidx.room.** { *; }
-dontwarn androidx.room.**

# Keep Retrofit and OkHttp models
-dontwarn okhttp3.**
-dontwarn retrofit2.**
-keepattributes Signature
-keepattributes *Annotation*
-keep class com.meriai.assistant.data.** { *; }
