# 📱 Meri AI — Native Android Personal AI Assistant (Kotlin + Jetpack Compose)

Welcome to **Meri AI**, a personal AI assistant built for Android using Kotlin and Jetpack Compose. Meri AI speaks natural **Hinglish** (Hindi written in English letters), recognizes your voice, speaks responses aloud, remembers personal facts locally in a Room database, and manages your daily tasks and reminders.

---

## 🌟 Key Architecture & Offline vs Internet Breakdown

| Feature | Storage / Processing | Needs Internet? | Notes |
| :--- | :--- | :--- | :--- |
| **Memory Bank** | SQLite (Room DB) | ❌ **No (100% Offline)** | Stored only on your device. Never leaves your phone. |
| **Tasks, To-Dos & Notes** | SQLite (Room DB) | ❌ **No (100% Offline)** | Accessible anywhere without network. |
| **Text-to-Speech (TTS)** | Android TTS Engine | ❌ **No (Offline)** | Uses built-in device voice synthesis. |
| **Chat History** | SQLite (Room DB) | ❌ **No (100% Offline)** | Saved locally; you can wipe it anytime. |
| **Voice Input (STT)** | Android SpeechRecognizer | 🌐 **Internet / Offline** | Uses Google Voice Recognition. Can be offline if Hindi language pack is installed in Gboard/Google app. |
| **AI Intelligence** | Gemini 3.8 Flash | 🌐 **Yes (Internet)** | Communicates with Google AI API for smart conversational responses. |

---

## 🔒 Security: Protecting Your API Key

> **Rule:** Never hardcode your API key inside any `.kt` file or commit it to GitHub.

In this project, your API key is injected via `local.properties`:
1. In the project root folder, open or create `local.properties`.
2. Add the following line:
   ```properties
   GEMINI_API_KEY=AIzaSy...YourKeyHere
   ```
3. `app/build.gradle.kts` automatically reads this property at compile time and exposes it via `BuildConfig.GEMINI_API_KEY`.
4. `local.properties` is already in `.gitignore`, so your secret will never be accidentally committed or leaked.

---

## 🚀 How to Run & Test on a Real Android Phone

### Step 1: Install Android Studio
1. Download **Android Studio** (Koala, Hedgehog, or newer) from [developer.android.com/studio](https://developer.android.com/studio).
2. Choose standard installation and ensure **Android SDK 35** and **JDK 17** are installed.

### Step 2: Open this Project
1. Launch Android Studio.
2. Click **Open** and select the `/android` folder.
3. Wait for Gradle Sync to finish (status bar at bottom right).

### Step 3: Enable Developer Options on Your Android Phone
1. On your phone, go to **Settings > About Phone**.
2. Tap **Build Number** 7 times rapidly until you see *"You are now a developer!"*.
3. Go back to **Settings > System > Developer Options**.
4. Enable:
   - ✅ **USB Debugging**
   - ✅ **Install via USB**

### Step 4: Connect Your Phone & Run
- **Via USB Cable**: Plug in your phone. Look at your phone screen and tap **"Always allow from this computer" -> Allow**.
- **Via Wireless Debugging (Android 11+)**: Ensure phone and laptop are on the same Wi-Fi. In Developer Options, tap *Wireless Debugging* -> *Pair device with QR code* in Android Studio.
- In Android Studio's top toolbar, choose your physical phone from the device dropdown.
- Click the green **Run (▶)** button (or press `Shift + F10`).
- The app will compile and launch directly on your phone!

---

## ⚠️ Real-World Limitations (Honest Disclosure)

1. **Background "Always-On" Wake Words**: Android battery optimizations (Doze mode) and Android 14+ foreground service restrictions prevent continuous microphone listening 24/7 in the background without draining battery or triggering strict OS warnings. Meri AI uses tap-to-talk to preserve battery and privacy.
2. **Text-to-Speech Pronunciation**: Some older Android phones don't have the high-quality Hindi/Indian English voice pre-installed. You can install it for free via phone *Settings > Accessibility > Text-to-Speech Output > Preferred Engine gear icon > Install Voice Data > Hindi / English (India)*.
3. **Speech Recognition Language**: If you speak fast Hinglish slang, Google's `hi-IN` recognizer might occasionally output Devanagari script. Meri AI automatically interprets both Romanized Hinglish and Devanagari.
4. **Gemini API Quota**: The free tier of Gemini has per-minute request limits. If exceeded, the app will gracefully show an offline prompt.
