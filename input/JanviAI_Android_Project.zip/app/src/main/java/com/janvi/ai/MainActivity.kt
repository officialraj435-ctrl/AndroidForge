package com.janvi.ai

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val bg = Color.rgb(12, 15, 30)
    private val panel = Color.rgb(26, 32, 55)
    private val accent = Color.rgb(135, 94, 255)
    private lateinit var messages: LinearLayout
    private lateinit var input: EditText
    private lateinit var apiKey: EditText
    private lateinit var send: Button
    private lateinit var scroll: ScrollView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(16, 14, 16, 10)
        }
        val header = TextView(this).apply {
            text = "✦  Janvi AI\nYour AI companion"
            textSize = 25f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(4, 12, 4, 18)
        }
        root.addView(header)
        val keyLabel = TextView(this).apply {
            text = "AI connection setup"
            setTextColor(Color.LTGRAY)
            textSize = 13f
        }
        root.addView(keyLabel)
        apiKey = EditText(this).apply {
            hint = "Paste Gemini API key"
            setSingleLine(true)
            textSize = 14f
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setBackgroundColor(panel)
            setPadding(12, 2, 12, 2)
        }
        root.addView(apiKey, LinearLayout.LayoutParams(-1, 48).apply { bottomMargin = 10 })
        val warning = TextView(this).apply {
            text = "API key is kept only for this session. For a public app, use a secure backend."
            setTextColor(Color.LTGRAY)
            textSize = 11f
            setPadding(2, 0, 2, 8)
        }
        root.addView(warning)
        scroll = ScrollView(this).apply { isFillViewport = true }
        messages = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(2, 6, 2, 6)
        }
        scroll.addView(messages)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        addBubble("Namaste! Main Janvi AI hoon. Neeche apna sawal likhein. Real AI replies ke liye Gemini API key chahiye.", false)
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        input = EditText(this).apply {
            hint = "Janvi se kuch bhi poochho..."
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setBackgroundColor(panel)
            setPadding(12, 0, 12, 0)
            textSize = 15f
        }
        row.addView(input, LinearLayout.LayoutParams(0, 54, 1f).apply { marginEnd = 8 })
        send = Button(this).apply {
            text = "Send"
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(accent))
        }
        row.addView(send, LinearLayout.LayoutParams(-2, 54))
        root.addView(row)
        setContentView(root)
        send.setOnClickListener { sendMessage() }
    }

    private fun addBubble(text: String, user: Boolean) {
        val tv = TextView(this).apply {
            this.text = (if (user) "You\n" else "Janvi AI\n") + text
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(14, 12, 14, 12)
            setBackgroundColor(if (user) Color.rgb(53, 58, 105) else panel)
        }
        messages.addView(tv, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 9 })
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun sendMessage() {
        val prompt = input.text.toString().trim()
        if (prompt.isEmpty()) return
        addBubble(prompt, true)
        input.setText("")
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(input.windowToken, 0)
        val key = apiKey.text.toString().trim()
        if (key.isEmpty()) {
            addBubble("AI abhi connect nahi hai. Upar Gemini API key paste karein. API key banane ke liye Google AI Studio use karein. Apni key kisi ke saath share na karein.", false)
            return
        }
        send.isEnabled = false
        val thinking = TextView(this).apply {
            text = "Janvi AI\nSoch rahi hoon..."
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(14, 12, 14, 12)
            setBackgroundColor(panel)
        }
        messages.addView(thinking, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 9 })
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        thread {
            val answer = try {
                val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=" + key)
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 20000
                    readTimeout = 30000
                    setRequestProperty("Content-Type", "application/json")
                    doOutput = true
                }
                val body = JSONObject().put(
                    "contents",
                    JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt))))
                )
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val response = stream.bufferedReader().use { it.readText() }
                conn.disconnect()
                if (code !in 200..299) "AI service error ($code). API key/model access check karein."
                else {
                    val obj = JSONObject(response)
                    obj.getJSONArray("candidates").getJSONObject(0)
                        .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
                }
            } catch (e: Exception) {
                "Connection error: ${e.message ?: "unknown error"}. Internet aur API key check karein."
            }
            runOnUiThread {
                messages.removeView(thinking)
                addBubble(answer, false)
                send.isEnabled = true
            }
        }
    }
}
