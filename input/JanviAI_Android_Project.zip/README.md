# Janvi AI — Android starter project

This is a starter native Android project with a simple chat screen. It removes Notes, Calculator, and Workplace, as requested.

## Important status
This is **source code**, not a compiled or tested APK. A build environment with Android SDK/Gradle is required to produce the APK.

## Build
Open this folder in Android Studio, allow Gradle sync, then select **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The debug APK normally appears at `app/build/outputs/apk/debug/app-debug.apk`.

## Connect AI
The first version sends a prompt to Google's Gemini API when a Gemini API key is entered in the app. Create a key through Google AI Studio and keep it private. API availability, model names, quotas, and billing depend on Google's current settings and terms.

**Security:** this direct-from-app API key approach is for a starter/demo only. Do not distribute an APK with a shared/private key. A production app should call a secure backend that stores the API key server-side.

## Future features
New features can be added by updating this project source and building a new APK. The installed app cannot safely rewrite its own code automatically; each code update requires a new signed app release or a carefully designed server-driven feature.
